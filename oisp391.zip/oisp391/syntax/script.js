/*
    Statements
*/
function test1() {
    if (true) {
        console.log(123)
    }
    for (let i = 0; i < 3; i++) {
        console.log(456)
    }
    // expression statements:
    console.log(789) // function call
    let exampleVar
    exampleVar = 5 // assignment
}

/*
    Expressions (and operators)
*/
function test() {
    console.log((5 + 3) / 2)
    console.log((true && true) || false)
    console.log(5 < 10 && 3 > 1)
}

test()
