function test() {

}

test()
