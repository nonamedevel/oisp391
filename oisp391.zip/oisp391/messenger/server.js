const { WebSocketServer } = require('C:/ws/index.js')
const fs = require('fs')

class Messenger {
    constructor() {        
        const wss = new WebSocketServer({ port: 8080 })
        this.connections = []

        const filePath = 'C:/oisp391/messenger/users.json'
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) throw err
            this.users = JSON.parse(data)
            console.log(this.users)
        })

        wss.on('connection', this.onConnection.bind(this))
    }
    onConnection(ws) {
        this.connections.push({ ws })
        ws.on('error', (err) => {
            console.error(err)
        })
        ws.on('message', (data) => {
            this.onMessage(ws, data)
        })
    }
    onMessage(ws, data) {
        const messageObj = JSON.parse(data)
        if (messageObj.type === 'user_name') {
            for (let connection of this.connections) {
                if (connection.ws === ws) {
                    connection.name = messageObj.data
                }
            }
        } else if (messageObj.type === 'text_message') {
            let username
            for (let connection of this.connections) {
                if (connection.ws === ws) {
                    username = connection.name
                    break
                }
            }
            for (let connection of this.connections) {
                connection.ws.send(JSON.stringify({
                    name: username,
                    text: messageObj.data,
                    timestamp: +new Date(),
                }))
            }
        } else if (messageObj.type === 'searchUser') {
            for (let user of users) {
                if (user === messageObj.info.data)
                    console.log(user)
                // JSON.stringify('addUser', user)
            }
        } else {
            console.log(messageObj)
            throw new Error('Unknown message type')
        }

         //else {
        //   const date = new Date()
        //   if (!firstMessage) {
        //     firstMessage = true
        //     for (let connection of connections) {
        //       if (connection.ws === ws) {
        //         connection.name = data.toString()
        //       }
        //     }
        //     return
        //   }
        //   let username
        //   for (let connection of connections) {
        //     if (connection.ws === ws) {
        //       username = connection.name
        //     }
        //   }
        //   for (let connection of connections) {
        //     const obj = {
        //       name: username,
        //       text: data.toString(),
        //       timestamp: +date,
        //     }
        //     connection.ws.send(JSON.stringify(obj))
        //   }
        // }
    }
}

const messenger = new Messenger()
