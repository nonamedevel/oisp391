/*
    https://www.npmjs.com/package/ws
    https://github.com/websockets/ws

    https://datatracker.ietf.org/doc/html/rfc6455
*/

// import WebSocket from 'ws'

// const ws = new WebSocket('ws://www.host.com/path')

// ws.on('error', console.error)

// ws.on('open', function open() {
//   ws.send('something')
// })

// ws.on('message', function message(data) {
//   console.log('received: %s', data)
// })



const { WebSocketServer } = require('C:/ws/index.js')
const fs = require('fs')

const wss = new WebSocketServer({ port: 8080 })
const connections = []
const users = []
const filePath = 'C:/oisp391/messenger/users.json'
users.readFile(filePath, 'utf8', function(err, data) {
        if (err) throw err
        console.log(data)
    })

wss.on('connection', function connection(ws) {
  connections.push({ ws })
  ws.on('error', console.error)
  let firstMessage

  ws.on('message', function message(data) {


    const date = new Date()
    if (!firstMessage) {
      firstMessage = true
      for (let connection of connections) {
        if (connection.ws === ws) {
          connection.name = data.toString()

        }
      }
      return
    }
    let username
    for (let connection of connections) {
      if (connection.ws === ws) {
        username = connection.name
      }
    }
    for (let connection of connections) {
      const obj = {
        name: username,
        text: data.toString(),
        timestamp: +date,
      }
      connection.ws.send(JSON.stringify(obj))
    }
  })

  // ws.send('something')
})
