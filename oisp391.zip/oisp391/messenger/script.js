/*
    https://www.npmjs.com/package/ws
    https://github.com/websockets/ws

    https://datatracker.ietf.org/doc/html/rfc6455
*/

// import WebSocket from 'ws'

// const ws = new WebSocket('ws://www.host.com/path')

// ws.on('error', console.error)

// ws.on('open', function open() {
//   ws.send('something')
// })

// ws.on('message', function message(data) {
//   console.log('received: %s', data)
// })


const { json } = require('stream/consumers')
const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })
const connections = []
wss.on('connection', function connection(ws) {
  connections.push({ws})
  ws.on('error', console.error)
  let firstMessage 

  ws.on('message', function message(data) {
    if (!firstMessage) {
      firstMessage = true
      for (let connection of connections) {
        if (connection.ws === ws) {
          connection.name = data.toString()
        }
      }
      return
    }
    for (let connection of connections) {
      const obj = {
        name: connection.name,
        text: data.toString(),
      }
      connection.ws.send(JSON.stringify(obj))
    }
  })

  // ws.send('something')
})
