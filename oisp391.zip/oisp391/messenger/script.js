/*
    https://www.npmjs.com/package/ws
    https://github.com/websockets/ws

    https://datatracker.ietf.org/doc/html/rfc6455
*/

// import WebSocket from 'ws'

// const ws = new WebSocket('ws://www.host.com/path')

// ws.on('error', console.error)

// ws.on('open', function open() {
//   ws.send('something')
// })

// ws.on('message', function message(data) {
//   console.log('received: %s', data)
// })




const { WebSocketServer } = require('C:/ws/index.js')
const fs = require('fs')

const wss = new WebSocketServer({ port: 8080 })
const connections = []
let users
const filePath = 'C:/oisp391/messenger/users.json'
fs.readFile(filePath, 'utf8', function(err, data) {
        if (err) throw err
        users = JSON.parse(data)
        console.log(users)
    })
function smsServer(type, data){
    return JSON.stringify({ type, data })
}

wss.on('connection', function connection(ws) {
  connections.push({ ws })
  ws.on('error', console.error)
  let firstMessage

  ws.on('message', function message(data) {
    const info = JSON.parse(data)
    if (info.type === 'message'){
      const date = new Date()
      if (!firstMessage) {
        firstMessage = true
        for (let connection of connections) {
          if (connection.ws === ws) {
            connection.name = info.data
          }
        }
        return
      }

      let username
      for (let connection of connections) {
        if (connection.ws === ws) {
          username = connection.name
        }
      }
      for (let connection of connections) {
        const obj = {
          name: username,
          text: info.data,
          timestamp: +date,
        }
        connection.ws.send(JSON.stringify(obj))
      }
    }else if (info.type === 'searchUser'){
      for (let user of users){
        if (user === info.info.data)
          console.log(user)
          // smsServer('addUser', user)
      }
    } //else {
    //   const date = new Date()
    //   if (!firstMessage) {
    //     firstMessage = true
    //     for (let connection of connections) {
    //       if (connection.ws === ws) {
    //         connection.name = data.toString()
    //       }
    //     }
    //     return
    //   }
    //   let username
    //   for (let connection of connections) {
    //     if (connection.ws === ws) {
    //       username = connection.name
    //     }
    //   }
    //   for (let connection of connections) {
    //     const obj = {
    //       name: username,
    //       text: data.toString(),
    //       timestamp: +date,
    //     }
    //     connection.ws.send(JSON.stringify(obj))
    //   }
    // }
  })

  // ws.send('something')
})
