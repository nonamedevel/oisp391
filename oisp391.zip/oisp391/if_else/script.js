function test1() {
    // const condition = true
    const condition = false
    if (condition) {
        console.log(123)
    } else {
        console.log(456)
    }
}

/*
    Not recommended
*/
function test2() {
    // const condition = true
    const condition = false
    if (condition)
        console.log(123)
    else
        console.log(456)
}

function test() {
    // const color = 'red'
    // const color = 'green'
    // const color = 'blue'
    const color = 'aqua'

    if (color === 'red') {
        console.log('красный')
    } else if (color === 'green') {
        console.log('зелёный')
    } else if (color === 'blue') {
        console.log('синий')
    } else {
        console.log('Cannot translate')
    }
}

test()
