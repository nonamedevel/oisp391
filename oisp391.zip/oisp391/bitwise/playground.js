function test1() {
    console.log((100).toString(2)) // 0b0110_0100
    console.log(2**6 + 2**5 + 2**2)
    console.log(2**7 + 2**6 + 2**5 + 2**4 + 2**3 + 2**2 + 2**1 + 2**0) // 0b1111_1111
}

function test1() {
    console.log(2**3 + 2**2 + 2**1 + 2**0) // 0b0000_1111 --> 15
    console.log(2**7 + 2**6 + 2**5 + 2**4) // 0b1111_0000 --> 240
    console.log(15 + 240)
    console.log(15 | 240)
}

function test1() {
    console.log(2**3 + 2**2 + 2**1 + 2**0) // 0b0000_1111 --> 15
    console.log(2**7 + 2**6 + 2**5 + 2**4) // 0b1111_0000 --> 240
    console.log(15 << 4)
    console.log(240 >> 4)
}

function test1() {
    console.log(1 << 0)
    console.log(1 << 1)
    console.log(1 << 2)
    console.log(1 << 3)
    console.log(1 << 4)
    console.log(1 << 5)
    console.log(1 << 6)
    console.log(1 << 7)
}

function test1() {
    console.log(15 >> 1)
    console.log(0b0000_1111 >> 1) // 0b00000111
}

function test1() {
    console.log(10) // 0b0000_1010
    /*
            0b0000_1010
            0b0000_0010
            0b0000_0010
    */
    console.log(10 & 0b0000_0010)
    /*
        0b0000_1010
        0b0000_1000
        0b0000_1000
    */
    console.log(10 & 0b0000_1000)
    console.log(10 & 0b0001_0000)
    /*
        0b0000_1010
        0b1111_0101
        0b0000_0000
    */
    console.log(10 & 0b1111_0101)
}

/*
    0b00001010
    0b00000101
    0b00000010
    0b00000001
    0b00000000
*/
function test() {
    for (let i = 0; i < 8; i++) {
        console.log((0b0000_1010 >> i) & 1)
    }
}


test()
