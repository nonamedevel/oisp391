/*
    (1) Написать программу для визуализации байта.
        Виджет должен состоять из 8 битов.
        Каждый бит может быть равен 1 или 0.
        При нажатии на бит он меняется на противоположный.
    (2) Реализовать сдвиг вправо и влево
*/
class Script {
    constructor(opts) {
        this.buttons = document.querySelectorAll('.bit')
        this.shiftLeftButton = document.querySelector('.shift_left')
        this.shiftRightButton = document.querySelector('.shift_right')
        for (const button of this.buttons) {
            button.addEventListener('click',this.onClick.bind(this))
        }
        this.shiftLeftButton.addEventListener('click',  this.shiftLeft.bind(this))
        this.shiftRightButton.addEventListener('click', this.shiftRight.bind(this))
    }
    onClick(event) {
        if (event.target.textContent === '0') {
            event.target.textContent = '1'
            event.target.style.backgroundColor = 'aquamarine'
        } else {    
            event.target.textContent = '0'
            event.target.style.backgroundColor = 'pink'
        }
    }
    shiftLeft() {
        let bits = '0b'
        for (const button of this.buttons) {
            bits += button.textContent
        }
        let number = Number(bits)

        number <<= 1    
        bits = number.toString(2).padStart(8, 0).slice(-8)
        console.log(bits)
        for (let i = 0; i < 8; i++) {
            this.buttons[i].textContent = bits[i]

            if (this.buttons[i].textContent === '1') {
                this.buttons[i].style.backgroundColor = 'aquamarine'
            } else {    
                this.buttons[i].textContent === '0'
                this.buttons[i].style.backgroundColor = 'pink'
            } 
        }
        
    }

    shiftRight() {
        let bits = '0b'
        for (const button of this.buttons) {
            bits += button.textContent
        }
        let number = Number(bits)

        // number = number << 1
        number >>= 1
        bits = number.toString(2).padStart(8, 0)
        for (let i = 0; i < 8; i++) {
            this.buttons[i].textContent = bits[i]
            
            if (this.buttons[i].textContent === '1') {
                this.buttons[i].style.backgroundColor = 'aquamarine'
            } else {    
                this.buttons[i].textContent === '0'
                this.buttons[i].style.backgroundColor = 'pink'
            } 
        }
    }
}

const script = new Script()