/*
    (1) Написать программу для визуализации байта.
        Виджет должен состоять из 8 битов.
        Каждый бит может быть равен 1 или 0.
        При нажатии на бит он меняется на противоположный.
    (2) Реализовать сдвиг вправо и влево
*/

const buttons = document.querySelectorAll('.bit')
function setBit() {
    for (const button of buttons) {
        button.addEventListener('click', function(event) {
            if (button.textContent === '0') {
                button.textContent = '1'
                button.style.backgroundColor = 'aquamarine'
            } else {    
                button.textContent = '0'
                button.style.backgroundColor = 'pink'
            }
        })
    }
    const shiftLeftButton = document.querySelector('.shift_left')
    shiftLeftButton.addEventListener('click', function() {
        let bits = '0b'
        for (const button of buttons) {
            bits += button.textContent
        }
        let number = Number(bits)

        number <<= 1    
        bits = number.toString(2).padStart(8, 0).slice(-8)
        console.log(bits)
        for (let i = 0; i < 8; i++) {
            buttons[i].textContent = bits[i]

            if (buttons[i].textContent === '1') {
                buttons[i].style.backgroundColor = 'aquamarine'
            } else {    
                buttons[i].textContent === '0'
                buttons[i].style.backgroundColor = 'pink'
            } 
        }
    })
    const shiftRightButton = document.querySelector('.shift_right')
    shiftRightButton.addEventListener('click', function() {
        let bits = '0b'
        for (const button of buttons) {
            bits += button.textContent
        }
        let number = Number(bits)

        // number = number << 1
        number >>= 1
        bits = number.toString(2).padStart(8, 0)
        for (let i = 0; i < 8; i++) {
            buttons[i].textContent = bits[i]
            
            if (buttons[i].textContent === '1') {
                buttons[i].style.backgroundColor = 'aquamarine'
            } else {    
                buttons[i].textContent === '0'
                buttons[i].style.backgroundColor = 'pink'
            } 
        }
    })
}

function shiftLeft() {

}

function shiftRight() {

}

setBit()
shiftLeft()
shiftRight()