function test1() {
    for (let i = 0; i < 10; i++) {
        console.log(i)
    }
}

function test2() {
    let i = 0
    while (i < 5) {
        console.log(i)
        i++
    }
}

/*
    Endless loop
    Warning! Be careful!
*/
function test3() {
    while (true) {
        console.log(123)
    }
}

function test() {
    const fileNames = [
        'rock.png',
        'paper.png',
        'scissors.png',
    ]
    // for (let i = 0; i < fileNames.length; i++) {
    //     console.log(fileNames[i])
    // }
    for (const fileName of fileNames) {
        console.log(fileName)
    }
}

test()
