/*
    (1) Создать структуру данных (максимально простую),
    которую можно использовать для хранения и обработки
    папки example_dir

    (2) На основе этой структуры данных создать простой
    пользовательский интерфейс который будет отражать
    иерархию папок и файлов
*/

const rootFolder = {
    name: 'example_dir',
    children: [     
        {
            name: 'file1.txt'
        },
        {
            name: 'file2.txt'
        },
        {
            name: 'dir1',
            children: [
                {
                    name: 'file4.txt'
                },
                {
                    name: 'dir4',
                    children: [
                        'file5.txt',
                        'file6.txt',
                        'file7.txt',
                    ]
                }
            ]
        },
        {
            name: 'file1.txt'
        },
        {
            name: 'dir3',
            children: [
                'file3.txt'
            ]
        },
        {
            name: 'dir2',
            children: [

            ]
        },
    ]  
}

function printFile(file){
    if (file.children){
        // debugger
        // console.log(file.name)
        for (const child of file.children){
            printFile(child)
        }
    } 
    console.log(file.name)
}

printFile(rootFolder)