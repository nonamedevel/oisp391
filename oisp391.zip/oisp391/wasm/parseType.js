const typeSection = [
    0x01, 0x10, 0x03,
        0x60, 0x02, 0x7f, 0x7f, 0x01, 0x7f,
        0x60, 0x00, 0x00,
        0x60, 0x00, 0x03, 0x7f, 0x7f, 0x7f
]

const exprectedResult = {
    name: 'type',
    size: 0x10,
    items: [
        {param: ['i32', 'i32'], result: ['i32']},
        {param: [], result: []},
        {param: [], result: ['i32', 'i32', 'i32']},
    ]
}
