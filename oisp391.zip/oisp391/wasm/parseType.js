const typeSection = [
    0x01, 0x10, 0x03,
        0x60, 0x02, 0x7f, 0x7f, 0x01, 0x7f,
        0x60, 0x00, 0x00,
        0x60, 0x00, 0x03, 0x7f, 0x7f, 0x7f
]

const exprectedResult = {
    name: 'type',
    size: 0x10,
    items: [
        {param: ['i32', 'i32'], result: ['i32']},
        {param: [], result: []},
        {param: [], result: ['i32', 'i32', 'i32']},
    ]
}
function parseTypeSection(){
    const exprectedResult = {
        name:'type',
        size: 0x00,
        items:[]
    }
    let index = 3
    while (index < typeSection.length){
        if(typeSection[index] !== 0x60 ){
            return
        }
        index++
        const dataParam = {param:[], result:[]}
        for (let num = 0; num<typeSection[index]; num++){
            dataParam[param].push(typeSection[index+num])
        } 
        index += typeSection[index]
        for (let num = 0; num<typeSection[index]; num++){
            dataParam[param].push(typeSection[index+num])
        } 
        items.push({})
    }
}