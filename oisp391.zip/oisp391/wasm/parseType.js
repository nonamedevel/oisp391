/*
    0x7C ⇒ f64
    0x7D ⇒ f32
    0x7E ⇒ i64
    0x7F ⇒ i32
*/
const typeData = { 
    0x7C: "f64",
    0x7D: "f32",
    0x7E: "i64",
    0x7F: "i32",
}
const typeSection = [
    0x01, 0x10, 0x03, // must be 16 bytes
        0x60, 0x02, 0x7f, 0x7f, 0x01, 0x7e,
        0x60, 0x00, 0x00,
        0x60, 0x00, 0x03, 0x7D, 0x7D, 0x7C,
]

const exprectedResult = {
    name: 'type',
    size: 0x10,
    items: [
        { param: ['i32', 'i32'], result: ['i32'] },
        { param: [], result: [] },
        { param: [], result: ['i32', 'i32', 'i32'] },
    ]
}
function parseTypeSection() {
    const result = {
        name: 'type',
        size: 0x00,
        items: []
    }
    let index = 3
    if (typeSection[1] != typeSection.length-2){
        return
    }
    let subsectionCount = 0
    result.size = typeSection[1]
    while (index < typeSection.length) {
        if (typeSection[index] !== 0x60) {
            return
        }
        index++
        const typeObj = { param: [], result: [] }
        for (let num = 1; num <= typeSection[index]; num++) {
            const type = typeData[typeSection[index + num]]
            if (!type){
                return
            }
            typeObj.param.push(type)
        }
        index += typeSection[index] + 1
        for (let num = 1; num <= typeSection[index]; num++) {
            const type = typeData[typeSection[index + num]]
            if (!type){
                return
            }
            typeObj.result.push(type)
        }
        index += typeSection[index] + 1
        result.items.push(typeObj)
        subsectionCount ++ 
    }
    if (subsectionCount !==  typeSection[2]){
        return
    }
    console.log(result)
}
parseTypeSection()