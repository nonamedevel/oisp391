const obj = {
    type: [
        3, 96, 2, 127, 127, 1,
        127, 96, 0, 0, 96, 0,
        3, 127, 127, 127
    ],
    function: [2, 0, 2],
    exports: [
        2, 6, 97, 100, 100, 84,
        119, 111, 0, 0, 3, 97,
        114, 114, 0, 1
    ],
    code: [
        2, 7, 0, 32, 0, 32, 1,
        106, 11, 8, 0, 65, 5, 65,
        10, 65, 15, 11
    ]
}

function objWasm(obj){
    const bytes = [0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00]

    const sectionNames = {
        'type': 0x01, 
        'function': 0x03,
        'exports': 0x07,
        'code': 0x0a
    }

    for (let secName of Object.keys(sectionNames)){
        if (obj[secName]){
            bytes.push(sectionNames[secName])
            bytes.push(obj[secName].length)
            bytes.push(...obj[secName])
        }
    }

    // console.log(bytes)
    return bytes
}

function compareArrs(arr1, arr2){
    if (arr1.length === arr2.length){
        for (let num = 0; num < arr1.length; num++){
            if (arr1[num] !== arr2[num]){
                console.log('False')
                break
            }
        }
        console.log('True')
    } else {
        console.log('False')
    }
}

arr1 = objWasm(obj)
const arr2 = [
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 
    0x01, 0x10, 0x03, // type
        0x60, 0x02, 0x7f, 0x7f, 0x01, 0x7f,
        0x60, 0x00, 0x00,
        0x60, 0x00, 0x03, 0x7f, 0x7f, 0x7f,
    0x03, 0x03, 0x02, 0x00, 0x02, // function
    0x07, 0x10, 0x02, // exports
        0x06, 0x61, 0x64, 0x64, 0x54, 0x77, 0x6f, 0x00, 0x00, 
        0x03, 0x61, 0x72, 0x72, 0x00, 0x01,
    0x0a, 0x12, 0x02, // code
        0x07, 0x00, 
            0x20, 0x00, 
            0x20, 0x01, 
            0x6a, 
        0x0b,
        0x08, 0x00, 
            0x41, 0x05, 
            0x41, 0x0a, 
            0x41, 0x0f, 
        0x0b,
]

compareArrs(arr1, arr2)
