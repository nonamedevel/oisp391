function test1() {
    const studentObj = {
        id: 1,
        name: 'Vasya',
    }
    const studentStr = JSON.stringify(studentObj)
    console.log(studentStr)
    console.log(typeof studentStr)
}

function test() {
    const studentStr = '{"id":1,"name":"Vasya"}'
    const studentObj = JSON.parse(studentStr)
    console.log(studentObj)
    console.log(typeof studentObj)
}

test()
