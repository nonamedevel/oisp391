/*
    In this example, there not difference between
    traditional syntax and arrow function.
    It's recommended to use traditional syntax
    in cases like this.
*/
function test1() {
    const func1 = function() {
        console.log('func1')
        console.log(this)
    }
    func1()
    const func2 = () => {
        console.log('func2')
        console.log(this)
    }
    func2()
}

function test1() {
    // console.log(this)
    const obj = {
        func() {
            // console.log(this)
            const func1 = function() {
                console.log('func1')
                console.log(this)
            }
            func1()
            const func2 = () => {
                console.log('func2')
                console.log(this)
            }
            func2()
        }
    }
    obj.func()
}

/*
    Old school JS
*/
function test1() {
    // console.log(this)
    var obj = {
        func: function() {
            // console.log(this)
            var func1 = function() {
                console.log('func1')
                console.log(this)
            }
            func1()
            var that = this
            var func2 = function() {
                console.log('func2')
                console.log(that)
            }
            func2()
        }
    }
    obj.func()
}

/*
    Return value
*/
function test() {
    const func1 = function() {
        return 'func1'
    }
    console.log(func1())
    const func2 = () => {
        return 'func2'
    }
    console.log(func2())
    const func3 = () => 'func3'
    console.log(func3())
}

test()
