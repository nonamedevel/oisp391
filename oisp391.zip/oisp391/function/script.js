/*
    Function is also an object
*/
function test1() {
    const func = function() {}
    func.property1 = 123
    func.method1 = function() {
        console.log(456)
    }
    console.log(func.property1)
    func.method1()
}

/*
    Function declaration vs Function expression
*/
function test1() {
    function funcDeclExample() {
        console.log('Function declaration')
    }
    const funcExprExample = function() {
        console.log('Function expression')
    }
    funcDeclExample()
    funcExprExample()
}

function test() {
    function printMessage(msg = 'Default message') {
        console.log(msg)
    }
    printMessage()
    printMessage('Hello there')
}

test()
