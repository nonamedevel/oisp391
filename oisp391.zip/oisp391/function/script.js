/*
    Function is also an object
*/
function test1() {
    const func = function() {}
    func.property1 = 123
    func.method1 = function() {
        console.log(456)
    }
    console.log(func.property1)
    func.method1()
}

/*
    Function declaration vs Function expression
*/
function test() {
    function funcDeclExample() {
        console.log('Function declaration')
    }
    const funcExprExample = function() {
        console.log('Function expression')
    }
    funcDeclExample()
    funcExprExample()
}

test()
