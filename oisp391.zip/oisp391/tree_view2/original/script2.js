const rootFolder = {
    name: 'fales',
    children: [
        { name: 'file1.txt' },
        { name: 'file2.txt' },
        {
            name: 'folder',
            children: [
                { name: 'file4.txt' },
                {
                    name: 'folder',
                    children: [
                        { name: 'file5.txt' },
                        { name: 'file6.txt' },
                        { name: 'file7.txt' }
                    ]
                }
            ]
        },
        { name: 'file1.txt' },
        {
            name: 'folder',
            children: [
                { name: 'file3.txt' }
            ]
        },
        {
            name: 'folder',
            children: []
        },
    ]
};

function createFileNode(file) {
    if (file.children) {
        const folderEl = document.createElement('div');
        folderEl.className = 'folder';

        //Функция принимает объект file.
        //Если у объекта есть свойство children
        //значит это папка, для которой создаётся <div> с классом folder


        const nameEl = document.createElement('div');
        nameEl.className = 'name';
        const textContainer = document.createElement('div')
        textContainer.classList = 'textContainer'
        textContainer.textContent = file.name;
        // Создаёт вложенный div с классом name для отображения названия папки.
        //Устанавливает текст содержимого — имя папки.

        nameEl.addEventListener('click', () => {
            folderEl.classList.toggle('open');
        });
        // Здесь при нажатие добавляем обработчик клика по имени папки
        // При клике переключается на класс open который отвечает за показ 
        // или скрытия папок
        nameEl.appendChild(textContainer)
        folderEl.appendChild(nameEl);



        const childrenContainer = document.createElement('div');
        childrenContainer.className = 'children';
        // Прикрепляет элемент с именем папки внутрь папки.
        // Создаёт контейнер для работы с классом children
        for (const child of file.children) {
            const childEl = createFileNode(typeof child === 'string' ? { name: child } : child);
            childrenContainer.appendChild(childEl);
        }
        //Проходим по каждому элементу внутри папки
        //Если элемент — это просто название файла (строка), то превращаем его в объект "{ name: имя_файла }"
        //Рекурсивно создаём HTML-элемент для каждого такого объекта и добавляем его внутрь контейнера с детьми.
        folderEl.appendChild(childrenContainer);
        return folderEl;
    } else {
        const fileEl = document.createElement('div');
        fileEl.className = 'file';
        fileEl.textContent = file.name;
        return fileEl;
    }

}
// Добавляем контейнер с вложенными элементами внутрь элемента папки.
//Возвращаем весь элемент папки с её содержимым.
//Если у объекта нет вложенных элементов, значит это файл: создаём блок с классом file и текстом имени файла, возвращаем его.

const explorerRoot = document.getElementById('file-explorer');
explorerRoot.addEventListener('click', function (event) {
    // if (!(event.target.classList.contains('name') || event.target.classList.contains('file'))) {
    //     return
    // }
    // console.log(event.target)

    // event.stopPropagation()

    if (alreadySelected) {
        alreadySelected.classList.remove('selected')
        alreadySelected = null
    }
    alreadySelected = event.target
    event.target.classList.add('selected')

})
let alreadySelected
let renameActive
let selectedParent
document.body.addEventListener('keydown', function (event) {
    if (event.code === 'F2') {
        if (alreadySelected) {
            
            selectedParent = alreadySelected.parentElement
            const inputDiv = document.createElement('input')
            inputDiv.classList.add('renameInput')
            renameActive = inputDiv
            selectedParent.append(renameActive)
            alreadySelected.remove()
        }
    } else if (event.code === 'Enter') {
        alreadySelected.textContainer = renameActive.value
        renameActive.remove()
        selectedParent.append(renameActive)
    }
})
explorerRoot.appendChild(createFileNode(rootFolder));
// Находим на странице контейнер, куда вставим дерево файлов.
// Создаём всю структуру из корневой папки и добавляем её в этот контейнер.


