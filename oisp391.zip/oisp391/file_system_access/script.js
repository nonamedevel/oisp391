const clickMeButton = document.querySelector('.click_me')
clickMeButton.addEventListener('click', function() {
    window.showOpenFilePicker()
})