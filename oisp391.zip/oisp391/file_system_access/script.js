function test1() {
    const clickMeButton = document.querySelector('.click_me')
    clickMeButton.focus()
    clickMeButton.addEventListener('click', async function() {
        try {
            const [fileHandle] = await window.showOpenFilePicker()
            // console.log(fileHandle) // FileSystemFileHandle
            const file = await fileHandle.getFile()
            console.log(file) // File
            const content = await file.text()
            console.log(content) // string
            console.log(typeof content)
        } catch (err) {
            if (err.name === 'AbortError') {
                return
            }
            console.dir(err)
        }
    })
}

function test1() {
    const clickMeButton = document.querySelector('.click_me')
    clickMeButton.focus()
    clickMeButton.addEventListener('click', async function() {
        try {
            const fileHandles = await window.showOpenFilePicker({
                multiple: true,
            })
            let total = 0
            for (const fileHandle of fileHandles) {
                const file = await fileHandle.getFile()
                const number = Number(await file.text())
                total += number
            }
            console.log(total)
        } catch (err) {
            if (err.name === 'AbortError') {
                return
            }
            console.dir(err)
        }
    })
}

function test() {
    const clickMeButton = document.querySelector('.click_me')
    clickMeButton.focus()
    clickMeButton.addEventListener('click', async function() {
        try {
            const fileHandle = await window.showSaveFilePicker()
            console.log(fileHandle) // FileSystemFileHandle
            const writable = await fileHandle.createWritable()
            console.log(writable) // FileSystemWritableFileStream
            await writable.write('Hello')
            await writable.close()
        } catch (err) {
            if (err.name === 'AbortError') {
                return
            }
            console.dir(err)
        }
    })
}

test()
