	
class Example {
	createInstance(param1, ...param2) {
        console.log(param1, param2)
	}
}

const example = new Example()
example.createInstance(123)
example.createInstance(123, 456)
example.createInstance(123, 456, 789)
