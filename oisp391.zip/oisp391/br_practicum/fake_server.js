class BaseServer {
    constructor(opts) {
        if (opts.delay) {
            this.delay = opts.delay
        } else {
            this.delay = 0
        }
        this.routes = {}
    }
    fetch(route, opts) {
        let method
        if (opts) {
            if (opts.method) {
                method = opts.method
            } else {
                method = 'GET'
            }
        } else {
            method = 'GET'
        }
        return new Promise((res) => {
            setTimeout(() => {
                if (method === 'GET') {
                    if (this.routes[route]) {
                        res(this.routes[route]())
                    } else {
                        res(false)
                    }
                } else if (method === 'POST') {
                    console.log(this.routes, route)
                    if (this.routes[route]) {
                        const item = JSON.parse(opts.body)
                        this.routes[route](item)
                        res(true)
                        this.writeTables()
                    } else {
                        res(false)
                    }
                } else {
                    res(false)
                }
            }, this.delay)
        })
    }
}

class FakeServer extends BaseServer {
    constructor(opts) {
        super(opts)

        this.routes['/get_all_students'] = () => {
            return this.tables.students
        }

        this.routes['/add_student'] = (student) => {
            this.tables.students.push(student)
        }

        this.routes['/users'] = () => {
            return this.tables.users
        }

        this.tables = this.readTables()
        if (!this.tables) {
            this.tables = {
                students: [],
                courses: [],
                users: [],
            }
        }
    }
    readTables() {
        const str = localStorage.getItem('fake_db')
        if (str) {
            return JSON.parse(str)
        }
    }
    writeTables() {
        const str = JSON.stringify(this.tables)
        localStorage.setItem('fake_db', str)
    }
}

async function test() {
    const server = new FakeServer({
        // delay: 3000,
    })
    let res

    res = await server.fetch('/add_student', {
        method: 'POST',
        body: JSON.stringify({
            id: 1,
            name: 'Vasya',
        })
    })
    console.log(res)

    res = await server.fetch('/add_student', {
        method: 'POST',
        body: JSON.stringify({
            id: 2,
            name: 'Masha',
        })
    })
    console.log(res)

    res = await server.fetch('/get_all_students')
    console.log(res)
    // res = await server.fetch('/courses')
    // console.log(res)
}

test()
