const container = document.querySelector('.container')
const logoutButton = container.querySelector('.logout')
logoutButton.addEventListener('click', function() {
    window.location.href = 'index.html'
})