/*

Проанализировать исходный код VS Code и выяснить как реализован следующий функционал
(желательно извлечь его и запустить в отдельном файле):
(1) При нажатии на кнопку Alt, кнопка Split Editor Right меняется на Split Editor Down - КАС
(2) С помощью Split Editor Right и Split Editor Down можно создать сетку из редакторов 2х2 - ДАА
(3) Перемещение строчек в файле с помощью Alt + ArrowUp/ArrowDown - ЗДС
(4) Как работает Explorer / Outline - ЧМА
(5) Как работают команды: фронтэнд (Command Palette, Ctrl + Shift + P) - ПИП
(6) Как работают команды: бэкэнд (CommandService, CommandRegistry и др.) - ТЮЮ

*/