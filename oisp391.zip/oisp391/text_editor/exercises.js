function onToggleReplaceButton() {
    this.replaceContainer?.classList.toggle('disabled');
    if (this.isReplaceShown()) {
        this.toggleReplaceButton?.element.classList.remove(...ThemeIcon.asClassNameArray(searchHideReplaceIcon));
        this.toggleReplaceButton?.element.classList.add(...ThemeIcon.asClassNameArray(searchShowReplaceIcon));
    } else {
        this.toggleReplaceButton?.element.classList.remove(...ThemeIcon.asClassNameArray(searchShowReplaceIcon));
        this.toggleReplaceButton?.element.classList.add(...ThemeIcon.asClassNameArray(searchHideReplaceIcon));
    }
    this.toggleReplaceButton?.element.setAttribute('aria-expanded', this.isReplaceShown() ? 'true' : 'false');
    this.updateReplaceActiveState();
    this._onReplaceToggled.fire();
}

const thisObj = {
    isReplaceShown() {},
    updateReplaceActiveState() {},
    _onReplaceToggled: {
        fire() {}
    },
    toggleReplaceButton: {
        element: document.querySelector('.replace')
    }
}

const onToggleReplaceButtonBound = onToggleReplaceButton.bind(thisObj)

class ThemeIcon {
    static asClassNameArray(){
        return []
    }
}

let searchShowReplaceIcon
let searchHideReplaceIcon

thisObj.toggleReplaceButton.element.addEventListener('click', onToggleReplaceButtonBound)