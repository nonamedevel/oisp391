/*

rendered-markdown
setting-item-markdown

*/

// src\vs\base\common\marked\marked.js
class _Lexer {
    static lex(src, options) {
        const lexer = new _Lexer(options)
        return lexer.lex(src)
    }
    lex(src) {
        console.log('lexing')
    }
}
class _Parser {
    static parse(tokens, options) {
        const parser = new _Parser(options)
        return parser.parse(tokens)
    }
    parse() {
        console.log('parsing')
    }
}
class Marked { // 2107
    constructor() {
        this.parse = this.parseMarkdown(_Lexer.lex, _Parser.parse)
    }
    parseMarkdown(lexer, parser) {
        const parse = (src, options) => {
            lexer()
            parser()
        }
        return parse
    }
}

const markedInstance = new Marked()
markedInstance.parse('src', {})
