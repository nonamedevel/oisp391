
class Marked {
    parse(num) {
        console.log(num, 'hello')
    }
}

const markedInstance = new Marked()
function marked(src, opt) {
    return markedInstance.parse(src, opt)
}

marked.use = function() {
    return marked
}
marked.parse = marked
const parse = marked


// ----------
markedInstance.parse(1)
marked.parse(2)
marked.use().parse(3)
parse.parse(4)
parse.use().parse(5)
Marked.prototype.parse(6)
