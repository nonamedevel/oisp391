/*
    TODO: Hide text "Loading document symbols"
*/

// placeholders
function basename(resource) {
    return resource
}
const dom = {
    $(className) {
        const elem = document.createElement('div')
        elem.classList.add(className.slice(1))
        return elem
    },
    append(container, elem) {
        container.append(elem)
    }
}

// src\vs\workbench\browser\parts\views\viewPaneContainer.ts
class ViewPaneContainer {
    onDidAddViewDescriptors(){
        const pane = this.createView()
        pane.render()
    }
    createView(){
        return new OutlinePane()
    }
}



// src\vs\base\browser\ui\splitview\paneview.ts
class Pane {
    setExpanded() {
        this.renderBody(document.body)
    }
    render() {
        this.element = document.body
        this.header = dom.$('.pane-header')
		dom.append(this.element, this.header)

        this.header.textContent = 'Outline'
        this.header.addEventListener('click', () => {
            this.setExpanded()
        })
    }
}

// src\vs\workbench\browser\parts\views\viewPane.ts
class ViewPane extends Pane {
    render(){
        super.render()
    }
    setExpanded() {
        super.setExpanded()
    }
}

// src\vs\workbench\contrib\outline\browser\outlinePane.ts

class OutlinePane extends ViewPane {
    constructor() {
        super()
        this.renderBody()
        this._handleEditorControlChanged()
    }
    _handleEditorControlChanged() {
        const resource = 'hello.txt'
        this._showMessage(`Loading document symbols for '${basename(resource)}'...`)
    }
    _showMessage(message) {
        this._message.textContent = message
    }
    renderBody(container) {
        this._message = dom.$('.outline-message')
        dom.append(document.body, this._message)
    }
}

// entry point
const viewPaneContainer = new ViewPaneContainer()
viewPaneContainer.onDidAddViewDescriptors()