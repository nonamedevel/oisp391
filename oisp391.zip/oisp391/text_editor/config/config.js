

// src\vs\base\browser\indexedDB.ts
class IndexedDB {

}

// src\vs\workbench\browser\web.main.ts
class BrowserMain {
    registerIndexedDBFileSystemProviders() {

    }
}


/*
    What does that do?
    There is no table called 'ItemTable'
*/
// src\vs\workbench\services\storage\browser\storageService.ts



