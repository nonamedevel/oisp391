/*


Disposable
    Button
    Widget
        SearchWidget


SearchWidget.constructor                            src\vs\workbench\contrib\search\browser\searchWidget.ts
    SearchWidget.render                             src\vs\workbench\contrib\search\browser\searchWidget.ts
        SearchWidget.renderToggleReplaceButton      src\vs\workbench\contrib\search\browser\searchWidget.ts
            "Toggle Replace"

onToggleReplaceButton


src\vs\workbench\contrib\search\browser\searchWidget.ts
src\vs\workbench\contrib\search\browser\media\searchview.css



*/