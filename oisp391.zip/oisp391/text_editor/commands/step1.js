/*
    TODO: 
    (1) 'workbench.action.toggleStatusbarVisibility' is used only once in the VS Code codebase,
    but we use it twice, which seems to be wrong - fix this
    (2) Improve service accessor and service IDs
*/


// src\vs\workbench\browser\workbench.ts

// src\vs\platform\instantiation\common\descriptors.ts
class SyncDescriptor {
	constructor(ctor, staticArguments, supportsDelayedInstantiation) {
		this.ctor = ctor
		this.staticArguments = staticArguments
		this.supportsDelayedInstantiation = supportsDelayedInstantiation
	}
}

const _registry = []

// src\vs\platform\instantiation\common\extensions.ts
function registerSingleton(id, ctorOrDescriptor) {
    ctorOrDescriptor = new SyncDescriptor(ctorOrDescriptor)
    _registry.push([id, ctorOrDescriptor])
}

function getSingletonServiceDescriptors() {
	return _registry
}

// src\vs\platform\commands\common\commands.ts
let ICommandService = 'commandService'

const CommandsRegistry = new class {
    constructor() {
        this._commands = new Map()
    }
    registerCommand(command) {
        this._commands.set(command.id, command.handler)
    }
    getCommand(id) {
        return this._commands.get(id)
    }
}


// src\vs\workbench\services\commands\common\commandService.ts
class CommandService {
    executeCommand(id) {
        const command = CommandsRegistry.getCommand(id)
        command()
    }
}

registerSingleton(ICommandService, CommandService)



// src\vs\platform\actions\common\actions.ts
class Action2 {
	constructor(desc) {
        this.desc = desc
    }
}

function registerAction2(ctor) {
    const action = new ctor()
    const command = action.desc
    CommandsRegistry.registerCommand({
        id: command.id,
        handler: () => {
            const statusbar = document.querySelector('.statusbar')
            if (statusbar.style.display === 'none') {
                statusbar.style.display = ''
            } else {
                statusbar.style.display = 'none'
            }
        }
    })
}

// src\vs\workbench\browser\actions\layoutActions.ts
class ToggleStatusbarVisibilityAction extends Action2 {
    static ID = 'workbench.action.toggleStatusbarVisibility'
    constructor() {
        super({
            id: ToggleStatusbarVisibilityAction.ID
        })
    }
}

registerAction2(ToggleStatusbarVisibilityAction)


// src\vs\platform\instantiation\common\serviceCollection.ts
class ServiceCollection {
    _entries = new Map()
	constructor(...entries) {
		for (const [id, service] of entries) {
			this.set(id, service)
		}
	}
    set(id, instanceOrDescriptor) {
        this._entries.set(id, instanceOrDescriptor)
    }
    get(id) {
        return this._entries.get(id)
    }
}

// src\vs\platform\instantiation\common\instantiation.ts
const IInstantiationService = 'instantiationService'

// src\vs\platform\instantiation\common\instantiationService.ts
class InstantiationService {
    constructor(_services = new ServiceCollection()) {
        this._services = _services
        this._services.set(IInstantiationService, this)
    }
    invokeFunction(fn) {
        const accessor = {
            get: (id) => {
                const result = this._getOrCreateServiceInstance(id)
                return result
            }
        }
        fn(accessor)
    }
    _getServiceInstanceOrDescriptor(id) {
        const instanceOrDesc = this._services.get(id)
        return instanceOrDesc
    }
    _getOrCreateServiceInstance(id) {
        const thing = this._getServiceInstanceOrDescriptor(id)
        return thing
    }
}

// src\vs\workbench\browser\actions\layoutActions.ts
class CustomizeLayoutAction {
    run(accessor) {
        const commandService = new (accessor.get(ICommandService).ctor)
        
        const toggleStatusbarVisibility = document.querySelector('.toggle_statusbar_visibility')
        toggleStatusbarVisibility.addEventListener('click', function() {
            commandService.executeCommand('workbench.action.toggleStatusbarVisibility')
        })
    }
}


// src\vs\code\electron-main\main.ts
class CodeMain {
    createServices() {
        const services = new ServiceCollection()
        const instantiationService = new InstantiationService(services)
    }
}



// src\vs\workbench\browser\workbench.ts
class Workbench {
    constructor(parent, options, serviceCollection) {
        this.serviceCollection = serviceCollection
    }
    startup() {
        const instantiationService = this.initServices(this.serviceCollection)
        return instantiationService
    }
    initServices(serviceCollection) {
        const contributedServices = getSingletonServiceDescriptors()
        for (const [id, descriptor] of contributedServices) {
			serviceCollection.set(id, descriptor);
		}

        // return new (registry.pop().ctor)
        const instantiationService = new InstantiationService(serviceCollection)
        return instantiationService
    }
}


// src\vs\workbench\browser\web.main.ts
class BrowserMain {
    open() {
        const services = this.initServices()
        const workbench = new Workbench(undefined, undefined, services.serviceCollection)
        const instantiationService = workbench.startup()

        const customizeLayoutAction = new CustomizeLayoutAction()
        instantiationService.invokeFunction(customizeLayoutAction.run)
    }
    initServices() {
        const serviceCollection = new ServiceCollection()
        return { serviceCollection }
    }
}

// src\vs\workbench\browser\web.factory.ts
function create() {
    new BrowserMain().open()
}


// src\vs\code\browser\workbench\workbench.ts
create()

/*
    TODO: who imports src\vs\code\browser\workbench\workbench.ts ?
*/

