/*
    workbench.action.toggleStatusbarVisibility


ICommandService             src\vs\platform\commands\common\commands.ts
CommandService              src\vs\workbench\services\commands\common\commandService.ts


*/


class CommandService {
    executeCommand(id) {
        const command = CommandsRegistry.getCommand(id)
        command()
    }
}


const CommandsRegistry = new class {
    constructor() {
        this._commands = new Map()
    }
    registerCommand(command) {
        this._commands.set(command.id, command.handler)
    }
    getCommand(id) {
        return this._commands.get(id)
    }
}

CommandsRegistry.registerCommand({
    id: 'workbench.action.toggleStatusbarVisibility',
    handler: () => {
        const statusbar = document.querySelector('.statusbar')
        if (statusbar.style.display === 'none') {
            statusbar.style.display = ''
        } else {
            statusbar.style.display = 'none'
        }
    }
})

const commandService = new CommandService()

const toggleStatusbarVisibility = document.querySelector('.toggle_statusbar_visibility')
toggleStatusbarVisibility.addEventListener('click', function() {
    commandService.executeCommand('workbench.action.toggleStatusbarVisibility')
})
