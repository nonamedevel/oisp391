
// src\vs\workbench\browser\workbench.ts

// src\vs\platform\instantiation\common\descriptors.ts
class SyncDescriptor {
	constructor(ctor, staticArguments, supportsDelayedInstantiation) {
		this.ctor = ctor
		this.staticArguments = staticArguments
		this.supportsDelayedInstantiation = supportsDelayedInstantiation
	}
}

const _registry = []

// src\vs\platform\instantiation\common\extensions.ts
function registerSingleton(ctorOrDescriptor) {
    ctorOrDescriptor = new SyncDescriptor(ctorOrDescriptor)
    _registry.push(ctorOrDescriptor)
}

function getSingletonServiceDescriptors() {
	return _registry
}

// src\vs\workbench\services\commands\common\commandService.ts
class CommandService {
    executeCommand(id) {
        const command = CommandsRegistry.getCommand(id)
        command()
    }
}

registerSingleton(CommandService)


// src\vs\platform\commands\common\commands.ts
const CommandsRegistry = new class {
    constructor() {
        this._commands = new Map()
    }
    registerCommand(command) {
        this._commands.set(command.id, command.handler)
    }
    getCommand(id) {
        return this._commands.get(id)
    }
}

// src\vs\platform\actions\common\actions.ts
class Action2 {
	constructor(desc) {
        this.desc = desc
    }
}

function registerAction2(ctor) {
    const action = new ctor()
    const command = action.desc
    CommandsRegistry.registerCommand({
        id: command.id,
        handler: () => {
            const statusbar = document.querySelector('.statusbar')
            if (statusbar.style.display === 'none') {
                statusbar.style.display = ''
            } else {
                statusbar.style.display = 'none'
            }
        }
    })
}

// src\vs\workbench\browser\actions\layoutActions.ts
class ToggleStatusbarVisibilityAction extends Action2 {
    static ID = 'workbench.action.toggleStatusbarVisibility'
    constructor() {
        super({
            id: ToggleStatusbarVisibilityAction.ID
        })
    }
}

registerAction2(ToggleStatusbarVisibilityAction)




class ServicesAccessor {
    get(id) {
        const registry = getSingletonServiceDescriptors()
        return new (registry.pop().ctor)
    }
}

let ICommandService
let accessor = new ServicesAccessor()
const commandService = accessor.get(ICommandService)

const toggleStatusbarVisibility = document.querySelector('.toggle_statusbar_visibility')
toggleStatusbarVisibility.addEventListener('click', function() {
    commandService.executeCommand('workbench.action.toggleStatusbarVisibility')
})
