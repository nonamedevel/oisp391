
class TabsWidget {
    constructor(opts) {
        this.container = document.querySelector('.tabs_widget')
        this.container.addEventListener('click', this.onClick.bind(this))

        this.content = document.querySelector('.content')
    }
    onClick(event) {
        if (!event.target.classList.contains('close_tab')) {
            return
        }
        event.target.parentElement.remove()
    }
    addTab(title, callback) {
        const oldActive = this.container.querySelector('.active')
        if (oldActive) {
            oldActive.classList.remove('active')
        }
        const tabElem = document.createElement('div')
        tabElem.classList.add('active')
        this.container.append(tabElem)
        const spanElem = document.createElement('span')
        spanElem.textContent = title
        tabElem.append(spanElem)
        const buttonElem = document.createElement('button')
        buttonElem.classList.add('close_tab')
        buttonElem.textContent = 'x'
        tabElem.append(buttonElem)
    }
    removeTab(event) {
        event.target.parentElement.remove()
    }
}

const tabsWidget = new TabsWidget({})
tabsWidget.addTab('index.html', function(container) {
    container.textContent = 'index.html content'
})
tabsWidget.addTab('script.js', function(container) {
    container.textContent = 'script.html content'
})
