
class TabsWidget {
    constructor(opts) {
        this.container = document.querySelector('.tabs_widget')
        this.container.addEventListener('click', this.onClick.bind(this))
        this.content = document.querySelector('.content')
        const addButton = document.createElement('button')
        addButton.classList.add('add_tab')
        addButton.textContent = '+'
        this.container.append(addButton)
    }
    onClick(event) {
        if (event.target.classList.contains('close_tab')) {
            const curTab = event.target.parentElement
            if (curTab.classList.contains('active')) {
                const prevTab = curTab.previousElementSibling
                if (prevTab) {
                    prevTab.classList.add('active')
                }
            }
            curTab.remove()
            return
        }
        else if (event.target.classList.contains('add_tab')) {
            this.addTab('added from button', function (container) {
                container.textContent = 'from button content'
                return
            })
        }
        const targetClosest = event.target.closest('.tab')
        if (targetClosest) {
            const oldActive = this.container.querySelector('.active')
            if (oldActive) {
                oldActive.classList.remove('active')
            }
            targetClosest.classList.add('active')
        }
    }
    addTab(title, callback) {
        const oldActive = this.container.querySelector('.active')
        if (oldActive) {
            oldActive.classList.remove('active')
        }
        const tabElem = document.createElement('div')
        tabElem.classList.add('tab')
        tabElem.classList.add('active')
        this.container.append(tabElem)
        const spanElem = document.createElement('span')
        spanElem.classList.add('title')
        spanElem.textContent = title
        tabElem.append(spanElem)
        const buttonElem = document.createElement('button')
        buttonElem.classList.add('close_tab')
        buttonElem.textContent = 'x'
        tabElem.append(buttonElem)
    }
    removeTab(event) {
        event.target.parentElement.remove()
    }
}

const tabsWidget = new TabsWidget({})
tabsWidget.addTab('index.html', function (container) {
    container.textContent = 'index.html content'
})
tabsWidget.addTab('script.js', function (container) {
    container.textContent = 'script.html content'
})
tabsWidget.addTab('style.css', function (container) {
    container.textContent = 'style.css content'
})
