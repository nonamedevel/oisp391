
class TabsWidget {
    constructor(opts) {
        this.container = document.querySelector('.tabs_widget')
        this.container.addEventListener('click', this.onClick.bind(this))
        this.content = document.querySelector('.content')
        this.addButton = document.createElement('button')
        this.addButton.classList.add('add_tab')
        this.addButton.textContent = '+'
        this.container.append(this.addButton)
        this.newTabIndex = 1
        this.freeTabIndices = []
        this.newTabSet = new Set()
    }
    onClick(event) {
        if (event.target.classList.contains('close_tab')) {
            const curTab = event.target.parentElement
            if (curTab.classList.contains('active')) {
                const prevTab = curTab.previousElementSibling
                if (prevTab) {
                    prevTab.classList.add('active')
                }
            }
            const tabName = curTab.querySelector('.title').textContent
            if (this.newTabSet.has(curTab)) {
                this.freeTabIndices.push(tabName.slice(8))
                this.newTabSet.delete(curTab)
            }
            curTab.remove()
            return
        }
        if (event.target.classList.contains('add_tab')) {
            let newTabName
            if (this.freeTabIndices.length > 0) {
                this.freeTabIndices.sort()
                newTabName = `New tab ${this.freeTabIndices.shift()}`
            } else {
                newTabName = `New tab ${this.newTabIndex++}`
            }

            const tab = this.addTab(newTabName, function (container) {
                container.textContent = 'New tab content'
                return
            })
            this.newTabSet.add(tab)
        }
        const targetClosest = event.target.closest('.tab')
        if (targetClosest) {
            const oldActive = this.container.querySelector('.active')
            if (oldActive) {
                oldActive.classList.remove('active')
            }
            targetClosest.classList.add('active')
        }
    }
    addTab(title, callback) {
        const oldActive = this.container.querySelector('.active')
        if (oldActive) {
            oldActive.classList.remove('active')
        }

        const tabElem = document.createElement('div')
        tabElem.classList.add('tab')
        tabElem.classList.add('active')
        this.container.append(tabElem)

        const spanElem = document.createElement('span')
        spanElem.classList.add('title')
        spanElem.textContent = title
        tabElem.append(spanElem)
        
        const buttonElem = document.createElement('button')
        buttonElem.classList.add('close_tab')
        buttonElem.textContent = 'x'
        tabElem.append(buttonElem)

        this.addButton.remove()
        this.container.append(this.addButton)

        return tabElem
    }
    removeTab(event) {
        event.target.parentElement.remove()
    }
}

const tabsWidget = new TabsWidget({})
tabsWidget.addTab('index.html', function (container) {
    container.textContent = 'index.html content'
})
tabsWidget.addTab('script.js', function (container) {
    container.textContent = 'script.html content'
})
tabsWidget.addTab('style.css', function (container) {
    container.textContent = 'style.css content'
})
tabsWidget.addTab('New tab hello there', function (container) {
    container.textContent = 'some content'
})
