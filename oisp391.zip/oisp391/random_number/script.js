
function test1() {
    const randNumber = Math.random()
    console.log(randNumber)
}

function test2() {
    const randNumber = Math.floor(Math.random() * 10)
    console.log(randNumber)
}

function test3() {
    const randNumber = Math.floor(Math.random() * 3)
    console.log(randNumber)
}

function test4() {
    // const randNumber = Math.floor(0 * 3) // min value
    const randNumber = Math.floor(0.999999 * 3) // max value
    console.log(randNumber)
}

function test5() {
    // const randNumber = Math.floor(0 * 6) + 5 // min value
    const randNumber = Math.floor(0.999999 * 6) + 5 // max value
    console.log(randNumber)
}

function test6() {
    const randNumber = Math.floor(Math.random() * 6) + 5
    console.log(randNumber)
}

/*
    {
        5: 200000,
        6: 200000,
        7: 200000,
        8: 200000,
        9: 100000,
        10: 100000,
    }
*/
function test71() {
    const arr = [0, 0, 0, 0, 0, 0]
    for (let i = 0; i < 1000000; i++) {
        const randNumber = Math.floor(Math.random() * 6) + 5
        arr[randNumber - 5]++
    }
    console.log(arr)
}

function test() {
    // const arr = [0, 0, 0, 0, 0, 0]
    const upperBound = 20
    const arr = Array(upperBound).fill(0)
    for (let i = 0; i < 1000000; i++) {
        const randNumber = Math.floor(Math.random() * upperBound) + 5
        arr[randNumber - 5]++
    }
    console.log(arr)
}

function test8() {
    const obj = {}
    for (let i = 0; i < 100000; i++) {
        const randNumber = Math.floor(Math.random() * 6000) + 5
        if (obj[randNumber]) {
            obj[randNumber]++
        } else {
            obj[randNumber] = 1
        }
    }
    console.log(obj)
}

test()
