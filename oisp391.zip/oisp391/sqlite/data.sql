INSERT INTO users (name, email, password, role) VALUES
('Alice Johnson', 'alice@example.com', 'pass123', 'student'),
('Bob Smith', 'bob@example.com', 'pass456', 'student'),
('Carol Lee', 'carol@example.com', 'pass789', 'student'),
('David Kim', 'david@example.com', 'pass321', 'instructor'),
('Eva Brown', 'eva@example.com', 'pass654', 'instructor');

INSERT INTO courses (title, description, category, instructor_id) VALUES
('Intro to Python', 'Learn Python from scratch', 'Programming', 4),
('Data Science Basics', 'Foundations of data analysis', 'Data Science', 5),
('Web Development', 'Build websites with HTML, CSS, JS', 'Web', 4),
('Machine Learning', 'Intro to ML concepts', 'AI', 5),
('SQL for Beginners', 'Learn SQL with hands-on examples', 'Databases', 4);

INSERT INTO enrollments (student_id, course_id) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 3),
(3, 4),
(3, 5),
(1, 5),
(2, 5),
(3, 2);

INSERT INTO lessons (course_id, title, content, video_url, position) VALUES
(1, 'Variables and Data Types', 'Intro to variables', 'https://video.com/py1', 1),
(1, 'Control Flow', 'If, else, loops', 'https://video.com/py2', 2),
(2, 'Data Cleaning', 'Handling missing data', 'https://video.com/ds1', 1),
(2, 'Visualization', 'Charts and graphs', 'https://video.com/ds2', 2),
(3, 'HTML Basics', 'Structure of web pages', 'https://video.com/web1', 1),
(3, 'CSS Styling', 'Design with CSS', 'https://video.com/web2', 2);

INSERT INTO assignments (lesson_id, title, instructions, due_date) VALUES
(1, 'Python Quiz 1', 'Answer basic Python questions', '2025-10-01'),
(2, 'Loop Practice', 'Write loop-based programs', '2025-10-05'),
(3, 'Clean Dataset', 'Fix missing values', '2025-10-03'),
(4, 'Create Chart', 'Visualize data with matplotlib', '2025-10-07'),
(5, 'Build a Web Page', 'Create a simple HTML page', '2025-10-02');

INSERT INTO submissions (assignment_id, student_id, file_url, score, feedback) VALUES
(1, 1, 'https://files.com/sub1', 85, 'Good job'),
(2, 2, 'https://files.com/sub2', 90, 'Excellent'),
(3, 3, 'https://files.com/sub3', 70, 'Needs improvement'),
(4, 1, 'https://files.com/sub4', 95, 'Well done'),
(5, 2, 'https://files.com/sub5', 88, 'Nice layout');

INSERT INTO discussions (course_id, user_id, title, message) VALUES
(1, 1, 'Help with loops', 'Can someone explain for loops?'),
(2, 2, 'Data cleaning tips', 'Best way to handle nulls?'),
(3, 3, 'CSS issues', 'My styles aren’t applying'),
(4, 1, 'ML confusion', 'What is overfitting?'),
(5, 2, 'SQL syntax', 'How do I join tables?');

INSERT INTO messages (discussion_id, user_id, message) VALUES
(1, 4, 'Try using range() in your loop'),
(2, 5, 'Use pandas fillna method'),
(3, 4, 'Check your CSS selectors'),
(4, 5, 'Overfitting means your model memorizes the training data'),
(5, 4, 'Use INNER JOIN for matching rows');
