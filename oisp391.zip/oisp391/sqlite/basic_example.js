const { DatabaseSync } = require('node:sqlite')

// const database = new DatabaseSync(':memory:')
const dbPath = 'C:/oisp391/sqlite/example.db'
const database = new DatabaseSync(dbPath)

// database.exec(`
//   CREATE TABLE data(
//     key INTEGER PRIMARY KEY,
//     value TEXT
//   ) STRICT
// `)

const insert = database.prepare('INSERT INTO data (key, value) VALUES (?, ?)')
insert.run(4, 'hello')
insert.run(5, 'world')
insert.run(6, 'привет')

const query = database.prepare('SELECT * FROM data ORDER BY key')
console.log(query.all())
