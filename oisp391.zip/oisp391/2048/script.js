function test1() {
    // let arr = [null, null, null, null]
    // let arr = [null, null, null, 2]
    let arr = [2, null, null, 4]
    // let arr = [2, 4, 8, 16]
    // let arr = [null, null, 2, 8] // [2, 8, null, null]
    function moveToLeft1(arr) {
        let newarr = []
        for (let i = 0; i < 4; i++) {
            if (arr[i] !== null) {
                newarr.push(arr[i])
            }
        }
        for (let i = newarr.length; i < 4; i++) {
            newarr.push(null)
        }
        return newarr
    }

    function moveToLeft(arr) {
        let newarr = [null,null,null,null]
        for (let i = 0, j = 0; i < 4; i++) {
            if (arr[i] !== null) {
                newarr[j] = arr[i]
                j++
            }
        }
        return newarr
    }
    arr = moveToLeft(arr)
    console.log(arr)
}

function test1() {
    let arr = [
        [2, 2, 2, null],
        [4, null, null, 8],
        [16, 4, null, null],
        [32, null, 16, null],
    ]
    function moveUp() {
        let newarr = [
            [null, null, null, null],
            [null, null, null, null],
            [null, null, null, null],
            [null, null, null, null],
        ]
        for (let col = 0; col < 4; col++) {
            for (let row = 0, lastNotOccupied = 0; row < 4; row++){
                if (arr[row][col] !== null) {
                    newarr[lastNotOccupied][col] = arr[row][col]
                    lastNotOccupied++
                }
            }
        }
        return newarr
    }
    arr = moveUp(arr)
    console.log(arr)
}

function test() {
    const arr1 = [
        [1,2,3,4],
        [5,6,7,8],
        [9,10,11,12],
        [13,14,15,16],
    ]
    // const arr = [
    //     [4,8,12,16],
    //     [3,7,11,15],
    //     [2,6,10,14],
    //     [1,5,9,13],
    // ]
    let arr2 = [
        [],
        [],
        [],
        [],
    ]
    for (let i = 0; i < 4; i++){
        for (let j = 0; j < 4; j++){
            arr2[j][i] = arr1[i][3-j]
        }
    } 
    console.log(arr2)
}

test()
