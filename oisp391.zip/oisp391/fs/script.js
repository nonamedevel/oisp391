const fs = require('fs')

function test1() {
    const filePath = 'C:/oisp391/fs/example.txt'
    const data = 'hello there!'
    fs.writeFile(filePath, data, function(err) {
        if (err) throw err
        console.log('done')
    })
}

function test1() {
    // const filePath = 'C:/oisp391/fs/example.txt'
    const filePath = 'C:/oisp391/fs/abc.txt'
    fs.readFile(filePath, 'utf8', function(err, data) {
        if (err) throw err
        console.log(data)
    })
}

function test() {
    let counter = 0
    const numbers = []
    const filePath1 = 'C:/oisp391/fs/num1.txt'
    const data1 = '150'
    fs.writeFile(filePath1, data1, function(err) {
        if (err) throw err
        counter++
        readFiles()
    })
    const filePath2 = 'C:/oisp391/fs/num2.txt'
    const data2 = '200'
    fs.writeFile(filePath2, data2, function(err) {
        if (err) throw err
        counter++
        readFiles()
    })
    function readFiles() {
        if (counter < 2) {
            return
        }
        const filePath1 = 'C:/oisp391/fs/num1.txt'
        fs.readFile(filePath1, 'utf8', function(err, data) {
            if (err) throw err
            numbers.push(Number(data))
            compute()
        })
        const filePath2 = 'C:/oisp391/fs/num2.txt'
        fs.readFile(filePath2, 'utf8', function(err, data) {
            if (err) throw err
            numbers.push(Number(data))
            compute()
        })
    }
    function compute() {
        if (numbers.length < 2) {
            return
        }
        const filePath = 'C:/oisp391/fs/num3.txt'
        const data = String(numbers[0] + numbers[1])
        fs.writeFile(filePath, data, function(err) {
            if (err) throw err
            console.log('done')
        })
    }
}

test()
