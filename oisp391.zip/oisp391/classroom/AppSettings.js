class Settings{
    constructor(opts){
        this.commonCellColor=opts.commonCellColor
        this.occupiedCellColor=opts.occupiedCellColor
        this.pickedCellColor=opts.pickedCellColor
    }
}
const settings1 = new Settings({
    commonCellColor: 'red',
    occupiedCellColor:'blue',
    pickedCellColor:'black'
})
