const gridSize = 5 * 7
const gridElem = document.querySelector('.grid')
const pickItemButton = document.querySelector('.pick_item')
const resetButton = document.querySelector('.reset')

function readArray() {
    let arr = []
    let str = localStorage.getItem('indices')
    if (str) {
        arr = JSON.parse(str)
    } else {
        arr = []
    }
    return arr
}
const arr = readArray()
if (arr.length > 0) {
    pickItemButton.disabled = false
    resetButton.disabled = false
} else {
    pickItemButton.disabled = true
    resetButton.disabled = true
}

for (let i = 0; i < gridSize; i++) {
    const cellElem = document.createElement('div')
    cellElem.classList.add('cell')
    gridElem.append(cellElem)
}

for (const item of arr) {
    gridElem.children[item].classList.add('occupied')
}

gridElem.children[2].classList.add('empty')

// gridElem.children[6].classList.add('empty')
// gridElem.children[7].classList.add('empty')
// gridElem.children[8].classList.add('empty')

// gridElem.children[11].classList.add('empty')
// gridElem.children[12].classList.add('empty')
// gridElem.children[13].classList.add('empty')

// gridElem.children[16].classList.add('empty')
// gridElem.children[17].classList.add('empty')
// gridElem.children[18].classList.add('empty')

// gridElem.children[21].classList.add('empty')
// gridElem.children[22].classList.add('empty')
// gridElem.children[23].classList.add('empty')

// gridElem.children[26].classList.add('empty')
// gridElem.children[27].classList.add('empty')
// gridElem.children[28].classList.add('empty')

// gridElem.children[31].classList.add('empty')
// gridElem.children[32].classList.add('empty')
// gridElem.children[33].classList.add('empty')

let index = 6
for (let i = 0; i < 6; i++) {
    for (let j = 0; j < 3; j++) {
        gridElem.children[index].classList.add('empty')
        index++
    }
    index += 2
}

for (let i = 0; i < gridSize; i++) {
    if (!gridElem.children[i].classList.contains('empty')) {
        gridElem.children[i].addEventListener('click', function () {
            gridElem.children[i].classList.add('occupied')
            const arr = readArray()
            if (arr.includes(i)) {return}
            arr.push(i)
            str = JSON.stringify(arr)
            localStorage.setItem('indices', str)
            pickItemButton.disabled = false
            resetButton.disabled = false
        })
    }
}

// gridElem.addEventListener('click',function(event){
//     if (event.target === gridElem){
//         return
//     }
//     if (!event.target.classList.contains('empty')){
//         event.target.classList.add('occupied')
//     }
// })

pickItemButton.addEventListener('click', function (event) {
    const arr = readArray()
    let randNumber = Math.floor(Math.random() * arr.length)
    let index = arr[randNumber]
    while (true) {
        if (gridElem.children[index].classList.contains('picked')) {
            if (arr.length === 1) { return }
            randNumber = Math.floor(Math.random() * arr.length)
            index = arr[randNumber]
        } else {
            gridElem.querySelectorAll('.picked').forEach(function (elem) {
                elem.classList.remove('picked')
            })
            gridElem.children[index].classList.add('picked')
            return
        }
    }
})

resetButton.addEventListener('click', function () {
    localStorage.removeItem('indices')
    for (let item = 0; item < gridSize; item++) {
        gridElem.children[item].classList.remove('occupied')
    }
    // for (let i = 0; i < gridSize; i++){
    //     gridElem.children[i].classList.remove('picked')
    // }
    gridElem.querySelectorAll('.picked').forEach(function (elem) {
        elem.classList.remove('picked')
    })
    pickItemButton.disabled = true
    resetButton.disabled = true
})
