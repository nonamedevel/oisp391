const http = require('http')

/*
    The simplest HTTP server
*/
function test1() {
    const server = http.createServer(function(req, res) {
        res.end('hello 123')
    })
    server.listen(12345)
}

/*
    Routes
*/
function test2() {
    const server = http.createServer(function(req, res) {
        console.log(req.url)
        res.end('hello 123')
    })
    server.listen(12345)
}

function test3() {
    const server = http.createServer(function(req, res) {
        const unwantedRoutes = [
            '/.well-known/appspecific/com.chrome.devtools.json',
            '/favicon.ico',
        ]
        if (!unwantedRoutes.includes(req.url)){
            console.log(req.url)
        }        
        res.end('hello 123')
    })
    server.listen(12345)
}

function test4() {
    const server = http.createServer(function(req, res) {
        const unwantedRoutes = [
            '/.well-known/appspecific/com.chrome.devtools.json',
            '/favicon.ico',
        ]
        if (!unwantedRoutes.includes(req.url)){
            console.log(req.url)
        }
        if (req.url === '/') {
            res.end('Main page')
        } else if (req.url === '/about') {
            res.end('About page')
        } else if (req.url === '/contacts') {
            res.end('Contacts')
        } else {
            res.end('404 Not found')
        }
    })
    server.listen(12345)
}

function test5() {
    const server = http.createServer(function(req, res) {
        const unwantedRoutes = [
            '/.well-known/appspecific/com.chrome.devtools.json',
            '/favicon.ico',
        ]
        if (!unwantedRoutes.includes(req.url)){
            console.log(req.url)
        }
        if (req.url === '/') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h1>Main page</h1>')
        } else if (req.url === '/about') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h2>About page</h2>')
        } else if (req.url === '/contacts') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h3>Contacts</h3>')
        } else {
            res.writeHead(404, {
                'Content-Type': 'text/html'
            })
            res.end('<h4>404 Not found</h4>')
        }
    })
    server.listen(12345)
}

function test() {
    const server = http.createServer(function(req, res) {
        const unwantedRoutes = [
            '/.well-known/appspecific/com.chrome.devtools.json',
            '/favicon.ico',
        ]
        if (!unwantedRoutes.includes(req.url)){
            console.log(req.url)
        }
        if (req.url === '/') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h1>Main page</h1>')
        } else if (req.url === '/about') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h2>About page</h2>')
        } else if (req.url === '/contacts') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h3>Contacts</h3>')
        } else {
            res.writeHead(404, {
                'Content-Type': 'text/html'
            })
            res.end('<h4>404 Not found</h4>')
        }
    })
    server.listen(12345)
}

test()
