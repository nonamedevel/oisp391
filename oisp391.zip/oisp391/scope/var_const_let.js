function test1(){
    // const number = 0
    // let number = 0
    var number = 0 
    number +=4
    console.log(number)
}

function test(){
    // for(let i = 0; i < 3; i++){
    //     console.log(i)
    // }
    for(var i = 0; i < 3; i++){
        console.log(i)
    }
    console.log(i)
}

test()