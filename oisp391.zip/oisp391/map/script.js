function test1() {
    const map = new Map()
    map.set('promise', 'обещание')
    map.set('promise', 'промис')
    map.set('map', 'карта')
    map.set('array', 'массив')
    map.set('list', 'список')
    map.set('line', 'строка')
    map.set('string', 'строка')
    console.log(map)
}

function test1() {
    const map = new Map([
        ['promise', 'обещание'],
        ['promise', 'промис'],
        ['map', 'карта'],
        ['array', 'массив'],
        ['list', 'список'],
        ['line', 'строка'],
        ['string', 'строка'],
    ])
    // console.log(map)
    // for (const elem of map) {
    //     console.log(elem)
    // }
    // for (const [key, val] of map) {
    //     console.log(key, val)
    // }
    // for (const key of map.keys()) {
    //     console.log(key)
    // }
    for (const value of map.values()) {
        console.log(value)
    }
}

function test1() {
    const person1 = {name: 'Valya', age: 30}
    const person2 = {name: 'Nikita', age: 20}
    const salaryMap = new Map()
    salaryMap.set(person1, 3000)
    salaryMap.set(person2, 5000)
    console.log(salaryMap.get(person1))
    console.log(salaryMap.get(person2))
    console.log(salaryMap)
}

function test1() {
    const person1 = {name: 'Valya', age: 30}
    const person2 = {name: 'Nikita', age: 20}
    const salaryMap = {}
    salaryMap[person1] = 3000
    salaryMap[person2] = 5000
    console.log(salaryMap[person1])
    console.log(salaryMap[person2])
    console.log(salaryMap)
}
function test() {
    const person1 = {name: 'Valya', age: 30}
    const person2 = {name: 'Nikita', age: 20}
    const salaryMap = {}
    const person1Obj= JSON.stringify(person1)
    const person2Obj= JSON.stringify(person2)
    salaryMap[person1Obj] = 3000
    salaryMap[person2Obj] = 5000
    console.log(salaryMap[person1Obj])
    console.log(salaryMap[person2Obj])
    console.log(salaryMap)
}

test()
