/*
    https://www.npmjs.com/package/ws
    https://github.com/websockets/ws

    https://datatracker.ietf.org/doc/html/rfc6455
*/

// import WebSocket from 'ws'

// const ws = new WebSocket('ws://www.host.com/path')

// ws.on('error', console.error)

// ws.on('open', function open() {
//   ws.send('something')
// })

// ws.on('message', function message(data) {
//   console.log('received: %s', data)
// })


const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })

wss.on('connection', function connection(ws) {
  ws.on('error', console.error)

  ws.on('message', function message(data) {
    console.log('received: %s', data)
  })

  ws.send('something')
})
