const obj = {
    key1: 5,
    key2: 10,
    key3: 15,
}

// console.log(obj.key1)
// console.log(obj.key2)
// console.log(obj.key3)

// console.log(obj['key1'])
// console.log(obj['key2'])
// console.log(obj['key3'])

// const keyName1 = 'key1'
// const keyName2 = 'key2'
// const keyName3 = 'key3'

// console.log(obj[keyName1])
// console.log(obj[keyName2])
// console.log(obj[keyName3])

// const {key1, key2, key3} = obj
// console.log(key1)
// console.log(key2)
// console.log(key3)

// const {key1: a, key2: b, key3: c} = obj
// console.log(a)
// console.log(b)
// console.log(c)

const {key1} = obj
console.log(key1)