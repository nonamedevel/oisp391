function test1() {
    const obj = {
        table: 'стол',
        chair: 'стул',
        sofa: 'диван',
        'twin bed': 'односпальная кровать',
    }
    console.log(obj.table)
    console.log(obj['twin bed'])
}

function test() {
    const obj = {}
    obj.table = 'стол'
    obj['twin bed'] = 'односпальная кровать'
    console.log(obj.table)
    console.log(obj['twin bed'])
}

test()
