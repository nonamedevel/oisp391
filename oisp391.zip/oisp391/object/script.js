function test1() {
    const obj = {
        table: 'стол',
        chair: 'стул',
        sofa: 'диван',
        'twin bed': 'односпальная кровать',
    }
    console.log(obj.table)
    console.log(obj['twin bed'])
}

function test1() {
    const obj = {}
    obj.table = 'стол'
    obj['twin bed'] = 'односпальная кровать'
    console.log(obj.table)
    console.log(obj['twin bed'])
}

function test() {
    const obj = {
        prop: 123,
        print1: function() {
            console.log(this.prop)
        },
        print2() {
            console.log(this.prop)
        },
        print3: () => {
            console.log(obj.prop)
        },
        prop2: [
            456, () => console.log(obj.prop2[0])
        ]
    }
    // console.log(obj)
    console.log(obj.prop)
    obj.print1()
    obj.print2()
    obj.print3()
    obj.prop2[1]()
}

test()
