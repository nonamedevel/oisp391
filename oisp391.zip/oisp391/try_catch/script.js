function test() {
    function printHello() {
        console.log('hello')
    }
    printHello && printHello()
    printGoodbye && printGoodbye()
}
