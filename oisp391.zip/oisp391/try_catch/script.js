function test1() {
    throw new Error('Something went wrong')
    console.log('done')
}

function test1() {
    try {
        // throw new Error('Something went wrong')
    } catch (err) {
        console.log(err)
    }
    console.log('done')
}

function test() {
    try {
        new Promise(function(res, rej) {
            rej(new Error('Something went wrong'))
        })
    } catch (err) {
        console.log(11, err)
    }
    console.log('done')
}

test()
