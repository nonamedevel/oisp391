const arr = [5, 10, 15]

// console.log(arr[0])
// console.log(arr[1])
// console.log(arr[2])

// const [a, b, c] = arr
// console.log(a)
// console.log(b)
// console.log(c)

const [five] = arr
console.log(five)