function test1() {
    const arr = []
    for (let i = 0; i < 5; i++) {
        arr.push(i * 100)
    }
    console.log(arr)
}

/*
    Not recommended
*/
function test() {
    // const arr = Array.from({length: 5}, (_,i) => i * 100)
    const arr = Array.from({length: 5}, (_,i) => {
        const val = i * 100
        console.log(val)
        return val
    })
    console.log(arr)
}

/*
    Given grid 6x5, compute indices of cells for column 2

     0  1  2  3  4  5
     6  7  8  9 10 11
    12 13 14 15 16 17
    18 19 20 21 22 23
    24 25 26 27 28 29
*/
function test() {
    const arr = []
    const step = 6
    const col = 5
    let item = 0
    item += col
    for (let i = 0; i < 5; i++) {
        arr.push(item)
        item += step
    }
    console.log(arr)
}

test()
