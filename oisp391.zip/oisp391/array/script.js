function test1() {
    const obj = {}
    const arr = []
    const func = function() {}
    console.log(typeof obj)
    console.log(typeof arr)
    console.log(typeof func)
}

function test2() {
    const arr = ['red', 'green', 'blue']
    console.log(arr[0])
    console.log(arr[1])
    console.log(arr[2])
}

function test() {
    const obj = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
    }
    console.log(obj.red)
    console.log(obj.green)
    console.log(obj.blue)
}

test()
