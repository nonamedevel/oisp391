function test1() {
    const obj = {}
    const arr = []
    const func = function() {}
    console.log(typeof obj)
    console.log(typeof arr)
    console.log(typeof func)
}

function test2() {
    const arr = ['red', 'green', 'blue']
    console.log(arr[0])
    console.log(arr[1])
    console.log(arr[2])
}

function test() {
    const obj = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
    }
    console.log(obj.red)
    console.log(obj.green)
    console.log(obj.blue)
    console.log(obj.hello)
}

function test4() {
    const obj = {
        red: function() {
            console.log('красный')
        },
        green: function() {
            console.log('зеленый')
        },
        blue: function() {
            console.log('синий')
        },
    }
    obj.red && obj.red()
    obj.green && obj.green()
    obj.blue && obj.blue()
    obj.hello && obj.hello()
}

test()
