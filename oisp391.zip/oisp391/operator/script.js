function test() {
    let number = 123
    console.log(number)
    number++ // increment
    console.log(number)
    number-- // decrement
    console.log(number)
}

test()
