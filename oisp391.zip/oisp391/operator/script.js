function test1() {
    let number = 123
    console.log(number)
    number++ // increment
    console.log(number)
    number-- // decrement
    console.log(number)
}

/*
    Logical operators
*/
function test2() {
    const functions = {
        printHello: function () {
            console.log('hello')
        }
    }

    // functions.printHello && functions.printHello()
    // functions.printGoodbye && functions.printGoodbye()

    if (functions.printHello) {
        functions.printHello()
    }
    if (functions.printGoodbye) {
        functions.printGoodbye()
    }
}

/*
    . Member access
    [] Computed member access
*/
function test() {
    const functions = {
        'print-hello': function () {
            console.log('hello')
        }
    }
    
    // functions['printHello'] && functions['printHello']()
    // functions['printGoodbye'] && functions['printGoodbye']()

    if (functions['print-hello']) {
        functions['print-hello']()
    }
    if (functions['print-goodbye']) {
        functions['print-goodbye']()
    }
}

test()
