class Vehicle {
    constructor(opts) {
        this.maxSpeed = opts.maxSpeed
        this.color = opts.color
        this.weight = opts.weight
        this.price = opts.price
    }
    print1() {
        console.log(this)
    }
}

class Car extends Vehicle {
    constructor(opts) {
        super(opts)
        this.numberOfDoors = opts.numberOfDoors
        this.used = opts.used
        this.transmission = opts.transmission
    }
    printInfoOld(language){
        let text
        if (language === 'Русский') {
        text = `макСкорость: ${this.maxSpeed}
цвет: ${this.color}
вес: ${this.weight}
цена: ${this.price}
кол-во дверей: ${this.numberOfDoors}
БУ: ${this.used}`
        } else {
           text = `Max speed: ${this.maxSpeed}
Color: ${this.color}
Weight: ${this.weight}
Price: ${this.price}
Amount of doors: ${this.numberOfDoors}
Used: ${this.used}`
        }
        console.log(text)
    }
    printInfo(lan){
        let text =''

        const form = {
            maxSpeed: ['максСкорость:','maxSpeed:'],
            color: ['цвет:', 'color:'],
            price: ['цена:', 'price:'],
            used: ['БУ:', 'Used:']
        }
        if (lan === 'ru'){
            for (const [key, val] of Object.entries(form)){
                text += val[0] + this[key]+' '
            } 
        } else {
            for (const [key, val] of Object.entries(form)){
                text += val[1] + this[key]+' '
            }
        }
        console.log(text)
    }
}

class Train extends Vehicle {

}

class Airplane extends Vehicle {

}

const car = new Car({
    maxSpeed: 100,
    color: 'gray',
    weight: 2000,
    price: 1000000,
    numberOfDoors: 4,
    used: true,
    transmission: 'automatic',
})
car.printInfo('Русский')
// car.printInfo('abc')
