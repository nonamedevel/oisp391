debugger

class Address {
    constructor() {
        console.log('Address.constructor')
    }
}

class VIP {
    constructor() {
        console.log('VIP.constructor')
    }
}

class Person {
    static vip = new VIP()
    address = new Address()
    constructor(name, age) {
        this.name = name
        this.age = age
        // this.address = new Address()
    }
}

const person1 = new Person('Vasya', 60)
console.log(person1)

const person2 = new Person('Masha', 40)
console.log(person2)
