function test1() {
    class Person {
        constructor(name, age) {
            this.name = name
            this.age = age
        }
        getAge() {
            return this.age
        }
        setAge(age) {
            this.age = age
        }
    }
    
    const person = new Person('Vasya', 20)
    console.log(person)
}

function test1() {
    const Person = class {
        constructor(name, age) {
            this.name = name
            this.age = age
        }
        getAge() {
            return this.age
        }
        setAge(age) {
            this.age = age
        }
    }
    
    const person = new Person('Vasya', 30)
    console.log(person)
}

function test1() {
    const person = new class {
        constructor(name, age) {
            this.name = name
            this.age = age
        }
        getAge() {
            return this.age
        }
        setAge(age) {
            this.age = age
        }
    } ('Vasya', 40)
    console.log(person)
}

function test() {
    const person1 = new class {
        constructor(name, age) {
            this.name = name
            this.age = age
        }
        getAge() {
            return this.age
        }
        setAge(age) {
            this.age = age
        }
    } ('Vasya', 40)
    const person2 = new person1.constructor('Masha', 20)
    console.log(person1)
    console.log(person2)
}

test()
