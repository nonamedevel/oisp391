function test1() {
    class Example {
        constructor(obj) {
            console.log(obj.msg)
        }
    }
    const example = new Example({
        msg: 'hello'
    })
}

function test1() {
    class Hello {
        msg = 'hello!'
    }
    class Example {
        constructor(obj = new Hello) {
            console.log(obj.msg)
        }
    }
    const example = new Example()
}

function test1() {
    class Example {
        constructor() {
            console.log(obj.msg)
        }
    }
    const obj = {
        msg: 'hello'
    }
    const example = new Example()
}

function test() {
    class Example {
        constructor(msg) {
            console.log(msg)
        }
    }
    function instantiate(ctor, msg) {
        return new ctor(msg)
    }
    const example = instantiate(Example, 'hello!')
}

test()
