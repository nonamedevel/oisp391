function test1() {
    function printInfo(person) {
        console.log(`${person.name} ${person.age}`)
    }
    printInfo({
        name: 'Vasya',
        age: 30,
    })
}

function test1() {
    function printInfo() {
        console.log(`${this.name} ${this.age}`)
    }
    printInfo.bind({
        name: 'Vasya',
        age: 30,
    })()
    const printInfoBound = printInfo.bind({
        name: 'Vasya',
        age: 30,
    })
    printInfoBound()
}

function test1() {
    function printInfo() {
        console.log(this)
    }
    printInfo()
}

function test1() {
    class Example {
        printInfo() {
            console.log(this)
        }
    }
    const example = new Example()
    example.printInfo()
}

function test() {
    const button = document.createElement('button')
    button.textContent = 'Click me'
    document.body.append(button)
    button.addEventListener('click', function(event) {
        console.log(this, this === event.target)
    })
}

test()
