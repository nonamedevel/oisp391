/*
    Добавить опции в конструктор класса.
    Пользователь может указать сколько промисов он хочет и максимальную задержку.
    Конструктор создает необходимое кол-во промисов
    с задержкой от 0 до масимальной задержки указанной пользователем (рандомно)
*/

function test1() {
    function asyncTask(delay, number) {
        return new Promise(function (res, rej) {
            setTimeout(function(){
                res(number)
            }, delay)
        })
    }
    function promise_summ(num){
        promise_sum+=num
        promise_count+=1
        if(promise_count===array.length){
            console.log(promise_sum)
        }
    }
    const array = [
        asyncTask(2000, 1),
        asyncTask(2500, 2),
        asyncTask(1000, 5),
        asyncTask(1300, 4),
        asyncTask(2700, 6),
    ]
    let promise_sum=0
    let promise_count=0
    for (const promise of array){
        promise.then(promise_summ).catch(function (num) {
            console.log(num)
        })
    }
}

function test1() {
    class AsyncSum {
        constructor() {
            this.array = [
                this.asyncTask(2000, 1),
                this.asyncTask(2500, 2),
                this.asyncTask(1000, 5),
                this.asyncTask(1300, 4),
                this.asyncTask(2700, 6),
            ]
            this.result = 0
            this.promiseCount = 0
            for (const promise of this.array){
                promise.then(this.printResult.bind(this)).catch(function (num) {
                    console.log(num)
                })
            }
        }
        asyncTask(delay, number) {
            return new Promise(function (res, rej) {
                setTimeout(function(){
                    res(number)
                }, delay)
            })
        }
        printResult(num){
            this.result += num
            this.promiseCount += 1
            if(this.promiseCount === this.array.length){
                console.log(this.result)
            }
        }
    }
    const asyncSum = new AsyncSum()
}

/*
    Добавить опции в конструктор класса.
    Пользователь может указать сколько промисов он хочет и максимальную задержку.
    Конструктор создает необходимое кол-во промисов
    с задержкой от 0 до масимальной задержки указанной пользователем (рандомно)
*/

function test() {
    class AsyncSum {
        constructor(opts) {
            this.array = []
            for (let i = 0; i < opts.count; i++){
                const delay = Math.floor(Math.random() * opts.maxDelay)
                const number = 1
                this.array.push(this.asyncTask(delay, number))
            }
            this.result = 0
            this.promiseCount = 0
            for (const promise of this.array){
                promise.then(this.printResult.bind(this)).catch(function (num) {
                    console.log(num)
                })
            }
        }
        asyncTask(delay, number) {
            return new Promise(function (res, rej) {
                setTimeout(function(){
                    res(number)
                }, delay)
            })
        }
        printResult(num){
            this.result += num
            this.promiseCount += 1
            if(this.promiseCount === this.array.length){
                console.log(this.result)
            }
        }
    }
    const asyncSum = new AsyncSum({maxDelay:4000, count:6})
}

test()