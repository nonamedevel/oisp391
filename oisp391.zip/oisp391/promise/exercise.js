/*
    You have 2 promises that resolve to 2 numbers.
    The first promise resolves after 2 seconds.
    The second promise resolves after 3 seconds.
    You need to add these 2 numbers and print the result.
*/

function test() {
    function asyncTask(delay, number) {
        return new Promise(function (res, rej) {
            setTimeout(function(){
                res(number)
            }, delay)
        })
    }
    const promise_1 = asyncTask(2000, 1)
    const promise_2 = asyncTask(3000, 2)
    promise_1.then(function (num) {
        console.log(num)
    }).catch(function (num) {
        console.log(num)
    })
    promise_2.then(function (num) {
        console.log(num)
    }).catch(function (num) {
        console.log(num)
    })
}
test()