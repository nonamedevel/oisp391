function test() {
    setTimeout(function(){
        console.log('Callbacks are simple and beautiful')
    }, 2000)
}

/*
    resolve + then
*/
function test1() {
    const promise = new Promise(function (res, rej) {
        res(123)
    })
    promise.then(function (num) {
        console.log(num)
    })
}

/*
    reject + catch
*/
function test1() {
    const promise = new Promise(function (res, rej) {
        rej(456)
    })
    promise.catch(function (num) {
        console.log(num)
    })
}

/*
    Toss a coin
*/
function test1() {
    const promise = new Promise(function (res, rej) {
        if (Math.random() < 0.5) {
            res(123)
        } else {
            rej(456) 
        }
    })
    promise.then(function (num) {
        console.log(num)
    }).catch(function (num) {
        console.log(num)
    })
}

/*
    UnhandledPromiseRejection
*/
function test1() {
    // new Promise(function(res, rej) {
    //     rej(new Error('Something went wrong'))
    // })
    new Promise(function(res, rej) {
        rej(123)
    })
}

function test1() {
    const promise = new Promise(function (res, rej) {
        setTimeout(function(){
            res(123)
        }, 3000)  
    })
    promise.then(function (num) {
        console.log(num)
    }).catch(function (num) {
        console.log(num)
    })
}

/*
    asyncTask
*/
function test1() {
    function asyncTask(delay) {
        return new Promise(function (res, rej) {
            setTimeout(function(){
                res(123)
            }, delay)
        })
    }
    asyncTask(2000).then(function (num) {
        console.log(num)
    }).catch(function (num) {
        console.log(num)
    })
}

test()
