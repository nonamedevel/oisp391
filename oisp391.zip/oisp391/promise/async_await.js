
function test() {
    function asyncTask(delay) {
        return new Promise(function (res, rej) {
            setTimeout(function(){
                res(456)
            }, delay)
        })
    }
    async function main() {
        try {
            const num = await asyncTask(2000)
            console.log(num)
        } catch(err) {
            console.log(err)
        }
    }
    main()
}

test()
