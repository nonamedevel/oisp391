function test1() {
    const str1 = 'single quote'
    const str2 = "double quote"
    const str3 = `back quote (backtick)`
    console.log(str1)
    console.log(str2)
    console.log(str3)
}

function test() {
    const name = 'Vasya'
    const city = 'Moscow'
    const age = 33
    const str = `Name: ${name}, City: ${city}, Age: ${age}`
    console.log(str)
}

test()