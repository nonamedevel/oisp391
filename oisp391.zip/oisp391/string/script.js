function test1() {
    const str1 = 'single quote'
    const str2 = "double quote"
    const str3 = `back quote (backtick)`
    console.log(str1)
    console.log(str2)
    console.log(str3)
}

function test1() {
    const name = 'Vasya'
    const city = 'Moscow'
    const age = 33
    const str = `Name: ${name}, City: ${city}, Age: ${age}`
    console.log(str)
}

function test1() {
    const user = {
        name: 'Vasya',
        city: 'Moscow',
        age: 33,
    }
    const str = `Name: ${user.name}, City: ${user.city}, Age: ${user.age}`
    console.log(str)
}

function test1() {
    const user = {
        name: 'Vasya',
        city: 'Moscow',
        age: 33,
    }
    // const str = 'Name: ' + user.name + ', City: ' + user.city + ', Age: ' + user.age

    // let str = 'Name: ' 
    // str += user.name 
    // str += ', City: ' 
    // str += user.city 
    // str += ', Age: ' 
    // str += user.age

    const arr = []

    arr.push('Name: ' + user.name)
    arr.push('City: ' + user.city)
    arr.push('Age: ' + user.age)

    console.log(arr.join(', '))
}

function test() {
    const user = {
        'Name: ': 'Vasya',
        'City: ': 'Moscow',
        'Age: ': 33,
    }
    let text = ''
    for (const [key, val] of Object.entries(user)) {
        text += `${key}${val} `
    }
    console.log(text)
}

test()
