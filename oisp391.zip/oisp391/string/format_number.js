/*
123456789       123 456 789
12345678        12 345 678
1234567         1 234 567
*/

function test() {
    function formatNumber(number){
        const arr = number.split('')
        let format = []
        debugger
        for (let i = number.length - 1 ; i >= 0; i--){
            format.push(arr[i])
            if ((arr.length - i) % 3 === 0){
                format.push(' ')
            }
        }
        if (format[format.length - 1] === ' '){
            format.pop()
        }
        return format.reverse().join('')
    }

    console.log(formatNumber('123456789'))
    console.log(formatNumber('12345678'))
    console.log(formatNumber('1234567'))
}

test()
